class StorageKeys {
  static const String isFavorites = "isFavorites";
  static const String isDarkmode = "isDarkmode";
}
