import 'package:flutter/widgets.dart';
import 'package:sample_cart/config/shared_pref.dart';
import 'package:sample_cart/config/storage_keys.dart';

import '../constants/app_variables.dart';
import '../controller/dark_mode.dart';

Future<void> getAllStorageValues() async {
  isDarkMode = await SharedPref.readBool(StorageKeys.isDarkmode);

  DarkModeProvider darkModeProvider = DarkModeProvider();
  darkModeProvider.isDarkMode = isDarkMode;
  debugPrint('Darkmode status $isDarkMode');



  
}
