// app_providers.dart

import 'package:provider/provider.dart';

import '../controller/add_to_cart.dart';
import '../controller/dark_mode.dart';
import '../controller/favorites.dart';
import '../controller/product_selection.dart';
import '../controller/products_controller.dart';

class AppProviders {
  static List<ChangeNotifierProvider> providers = [
    ChangeNotifierProvider<ProductController>(
      create: (_) => ProductController(),
    ),
    ChangeNotifierProvider<DarkModeProvider>(
      create: (_) => DarkModeProvider(),
    ),
    ChangeNotifierProvider<FavoritesController>(
      create: (_) => FavoritesController(),
    ),
    ChangeNotifierProvider<AddToCartController>(
      create: (_) => AddToCartController(),
    ),
    ChangeNotifierProvider<ProductSelectionModel>(
      create: (_) => ProductSelectionModel(),
    ),
  ];
}
