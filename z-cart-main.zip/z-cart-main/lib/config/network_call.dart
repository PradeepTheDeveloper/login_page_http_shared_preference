import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../constants/app_constants.dart';

class HttpService {
  Future<dynamic> get(String endpoint) async {
    final url = Uri.parse('$baseUrl/$endpoint');

    try {
      final response = await http.get(url);
      debugPrint("url-----$url");
      debugPrint("url-response----$response");

      if (response.statusCode == 200) {
        return jsonDecode(response.body) as List;
      } else {
        throw Exception(
            'HTTP GET request failed with status: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to perform GET request: $e');
    }
  }

  Future<dynamic> post(String endpoint, dynamic body) async {
    final url = Uri.parse('$baseUrl/$endpoint');
    final headers = <String, String>{
      'Content-Type': 'application/json',
    };

    try {
      final response =
          await http.post(url, headers: headers, body: jsonEncode(body));

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception(
            'HTTP POST request failed with status: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to perform POST request: $e');
    }
  }
}
