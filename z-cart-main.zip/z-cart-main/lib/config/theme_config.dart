import 'package:flutter/material.dart';
import 'package:sample_cart/constants/app_constants.dart';

class ThemeConfig {
  static ThemeData lightTheme = ThemeData.light().copyWith(
    primaryColor: AppColors.appPrimaryColor,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.appPrimaryColor,
      titleTextStyle: TextStyle(color: AppColors.appColorWhite),
    ),
    cardColor: AppColors.appColorWhite,

    iconTheme: const IconThemeData(
        color: AppColors.appPrimaryColor), // Icon color for light theme
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      selectedItemColor: AppColors.appPrimaryColor,
      unselectedItemColor: AppColors.appSecondaryColor,
    ),
    switchTheme: SwitchThemeData(
      trackColor:
          MaterialStateColor.resolveWith((states) => AppColors.AppColorGrey),
      thumbColor:
          MaterialStateColor.resolveWith((states) => AppColors.appPrimaryColor),
    ),

    buttonTheme: const ButtonThemeData(
      buttonColor: AppColors.appPrimaryColor,
      textTheme: ButtonTextTheme.primary,
    ),

    // Add more theme configurations for other elements
  );

  static ThemeData darkTheme = ThemeData.dark().copyWith(
    primaryColor: AppColors.appSecondaryColor,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.appSecondaryColor,
    ),
    cardColor: AppColors.appSecondaryColor,
    iconTheme: const IconThemeData(
        color: AppColors.appPrimaryColor), // Icon color for dark theme
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      selectedItemColor: AppColors.appPrimaryColor,
      unselectedItemColor: AppColors.appColorWhite,
    ),

    switchTheme: SwitchThemeData(
      trackColor:
          MaterialStateColor.resolveWith((states) => AppColors.AppColorGrey),
      thumbColor:
          MaterialStateColor.resolveWith((states) => AppColors.appPrimaryColor),
    ),
    // Add more theme configurations for other elements
  );

  static Color getTextColor(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark
        ? AppColors.appPrimaryColor
        : AppColors.appSecondaryColor;
  }
}
