import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample_cart/view/walkthrough_screen.dart';
import '../constants/app_constants.dart';
import 'config/app_providers.dart';
import 'config/get_all_stored_values.dart';
import 'controller/dark_mode.dart';
import 'config/theme_config.dart';
import 'route/app_route.dart';
import 'route/route.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await getAllStorageValues();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: AppProviders.providers,
      child: Consumer<DarkModeProvider>(
        builder: (context, appMode, _) {
          // Initialize the variables after the MaterialApp widget
          currentContext = context;
          textTheme.apply(displayColor: ThemeConfig.getTextColor(context));
          return MaterialApp(
            navigatorKey: NavigationService.navigatorKey,
            initialRoute: '/',
            debugShowCheckedModeBanner: false,
            title: 'My App',
            theme: appMode.isDarkMode
                ? ThemeConfig.darkTheme
                : ThemeConfig.lightTheme,
            home: WalkthroughScreen(),
            routes: AppRoutes.routes,
          );
        },
      ),
    );
  }
}
