import 'package:flutter/material.dart';

import '../config/network_call.dart';
import '../constants/app_constants.dart';
import '../models/products.dart';

class ProductController extends ChangeNotifier {
  final HttpService _httpService = HttpService();
  List<Product> _products = [];
  List<Product> _productsLimit = [];
  List<String> _categories = [];
  String _selectedCategory = '';
  bool _isLoading = false;
  String _errorMessage = '';

  List<Product> get products => _products;
  List<Product> get productsWithLimit => _productsLimit;
  List<String> get categories => _categories;
  String get selectedCategory => _selectedCategory;
  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;

  Future<void> fetchProducts() async {
    _isLoading = true;
    _errorMessage = '';

    try {
      final jsonData = await _httpService.get(endUrlProduct);
      _products = (jsonData as List<dynamic>)
          .map((item) => Product.fromJson(item))
          .toList();
      // Sort the products by price by default (low to high)
      sortProductsByPrice(true);
    } catch (e) {
      _errorMessage = 'Failed to fetch products: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> fetchProductsLimit() async {
    _isLoading = true;
    _errorMessage = '';

    try {
      final jsonData = await _httpService.get(endUrlProduct);
      _productsLimit = (jsonData as List<dynamic>)
          .map((item) => Product.fromJson(item))
          .toList();

      // Sort the limited products by price by default (low to high)
      sortProductsByPrice(true);

      // Limit the list to only show five items
      if (_productsLimit.length > 5) {
        _productsLimit = _productsLimit.sublist(0, 5);
      }
    } catch (e) {
      _errorMessage = 'Failed to fetch products: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void sortProductsByPrice(bool lowToHigh) {
    _products.sort((a, b) {
      if (lowToHigh) {
        return a.price.compareTo(b.price);
      } else {
        return b.price.compareTo(a.price);
      }
    });
    notifyListeners();
  }

  List<Product> findByCategory(String category) {
    return _products.where((product) => product.category == category).toList();
  }

  List<Product> findByID(int id) {
    return _products.where((product) => product.id == id).toList();
  }

  Future<void> fetchCategories() async {
    _isLoading = true;
    _errorMessage = '';

    try {
      final jsonData = await _httpService.get(endUrlProduct);
      _categories = (jsonData as List<dynamic>)
          .map((item) => item['category'].toString())
          .toSet()
          .toList();
    } catch (e) {
      _errorMessage = 'Failed to fetch categories: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> filterProductsByCategory(String category) async {
    _selectedCategory = category;
    notifyListeners();
  }

  List<Product> findByFavorites({bool isFavorites = true}) {
    return _products
        .where((product) => product.isFavorite == isFavorites)
        .toList();
  }

  List<Product> findMycart({bool addToCart = true}) {
    return _products
        .where((product) => product.addToCart == addToCart)
        .toList();
  }

  // Method to increment the quantity of a product in the cart
  void incrementQuantity(int productId) {
    final productIndex =
        _products.indexWhere((product) => product.id == productId);
    if (productIndex != -1) {
      _products[productIndex].quantity++;
      notifyListeners();
    }
  }

// Method to decrement the quantity of a product in the cart
  void decrementQuantity(int productId) {
    final productIndex =
        _products.indexWhere((product) => product.id == productId);
    if (productIndex != -1 && _products[productIndex].quantity > 1) {
      _products[productIndex].quantity--;
    } else if (productIndex != -1) {
      _products[productIndex].quantity = 0;
      _products[productIndex].addToCart = false;
    }
    notifyListeners();
  }
}
