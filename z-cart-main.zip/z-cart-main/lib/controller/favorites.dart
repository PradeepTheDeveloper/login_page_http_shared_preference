import 'package:flutter/material.dart';

import '../models/products.dart';

class FavoritesController extends ChangeNotifier {
  List<Product> _products = [];

  List<Product> get products => _products;

  void toggleFavoriteStatus(Product product) {
    product.isFavorite = !product.isFavorite;
    notifyListeners();
  }
}
