import 'package:flutter/material.dart';
import '../config/shared_pref.dart';
import '../config/storage_keys.dart';

class DarkModeProvider with ChangeNotifier {
  bool _isDarkMode = false;

  DarkModeProvider() {
    _loadDarkModeFromPrefs(); // Load the value during initialization
  }

  bool get isDarkMode => _isDarkMode;

  set isDarkMode(bool value) {
    _isDarkMode = value;
    notifyListeners();
    SharedPref.storeBool(StorageKeys.isDarkmode, value); // Store the value
  }

  // Method to load the dark mode value from shared preferences
  void _loadDarkModeFromPrefs() async {
    bool darkModeValue = await SharedPref.readBool(StorageKeys.isDarkmode);
    _isDarkMode = darkModeValue;
    notifyListeners();
  }
}
