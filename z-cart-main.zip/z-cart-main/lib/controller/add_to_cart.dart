import 'package:flutter/material.dart';

import '../models/products.dart';

class AddToCartController extends ChangeNotifier {
  List<Product> _products = [];

  List<Product> get products => _products;

  void toggleAddtoCartStatus(Product product) {
    product.addToCart = !product.addToCart;
    notifyListeners();
  }
}
