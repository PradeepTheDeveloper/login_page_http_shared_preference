import 'package:flutter/material.dart';

class ProductSelectionModel extends ChangeNotifier {
  Color? selectedColor;
  String? selectedSize; 

  void updateColor(Color color) {
    selectedColor = color;
    notifyListeners();
  }

  void updateSize(String size) {
    selectedSize = size;
    notifyListeners();
  }
}
