import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError(
        'DefaultFirebaseOptions have not been configured for web - '
        'you can reconfigure this by running the FlutterFire CLI again.',
      );
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for macos - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.windows:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

// replace your App's Firebase Key
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AaaaSyD6FDF4yC2pZ2EdrhPCfckkll57laaaaaa',
    appId: '1:111122391111:android:aaaaae33f9ed9b7735aaaa',
    messagingSenderId: '111122391111',
    projectId: 'sample_cart',
    storageBucket: 'sample_cart-202a4.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AaaaSyD6FDF4yC2pZ2EdrhPCfckkll57laaaaaa',
    appId: '1:111122391111:android:aaaaae33f9ed9b7735aaaa',
    messagingSenderId: '111122391111',
    projectId: 'sample_cart',
    storageBucket: 'sample_cart-202a4.appspot.com',
    iosClientId:
        '111122391111-c72sou98kcrm57on3an338imi3h38sd6.apps.googleusercontent.com',
    iosBundleId: 'com.sample-cart.pradeepthedeveloper',
  );
}
