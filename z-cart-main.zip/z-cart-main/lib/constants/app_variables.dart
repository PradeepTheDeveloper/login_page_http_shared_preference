import 'package:flutter/material.dart';

import '../models/products.dart';

late BuildContext currentContext;
final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
final textTheme = Theme.of(currentContext)
    .textTheme
    .apply(displayColor: Theme.of(currentContext).colorScheme.onSurface);

late bool isDarkMode;
DateTime get timeNow => DateTime.now();
Duration requestTimeout = const Duration(seconds: 60);
const String baseUrl = "https://fakestoreapi.com";
const String endUrlProduct = "products";

List<Product> products = [];
List<Product> productsWithLimit = [];

final List<Map<String, dynamic>> categories = [
  {'name': "men's clothing", 'icon': Icons.shopping_bag},
  {'name': 'electronics', 'icon': Icons.watch},
  {'name': "women's clothing", 'icon': Icons.shopping_cart},
  {'name': 'jewelery', 'icon': Icons.wallet},
];

final List<Map<String, dynamic>> PriceCategory = [
  {'name': "\$ 100", 'icon': Icons.arrow_forward_ios},
  {'name': '\$ 300', 'icon': Icons.arrow_forward_ios},
  {'name': "\$ 400", 'icon': Icons.arrow_forward_ios},
  {'name': '\$ 1000', 'icon': Icons.arrow_forward_ios},
];

final List<List<Color>> cardGradients = [
  [Colors.red, Colors.orange], // Gradient for first card
  [Colors.blue, Colors.indigo], // Gradient for second card
  [Colors.green, Colors.lightGreen], // Gradient for third card
  [Colors.purple, Colors.pink], // Gradient for fourth card
  [Colors.teal, Colors.cyan], // Gradient for fifth card
  [Colors.yellow, Colors.amber],
  // Add more gradients as needed
];

final List<String> sortOptions = ['Low to High', 'High to Low'];

String selectedSortOption = 'Low to High';

final List<String> sizes = ['S', 'M', 'L', 'XL', 'XXL'];

String? selectedSize;

Color? selectedColor;

final List<String> steps = [
  'Order Placed',
  'Confirmed Order',
  'Processing Order'
];
