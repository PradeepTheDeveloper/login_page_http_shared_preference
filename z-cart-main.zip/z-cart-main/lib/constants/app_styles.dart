import 'package:flutter/material.dart';

class AppTextStyle extends StatelessWidget {
  const AppTextStyle({
    Key? key,
    required this.name,
    required this.style,
    this.fontWeight,
    this.maxLines = 2, // Add a default value for maxLines
    this.align = TextAlign.left,
    this.textColor,
  }) : super(key: key);

  final String name;
  final TextStyle style;
  final FontWeight? fontWeight;
  final int maxLines; // Define the maxLines property
  final TextAlign align;
  final Color? textColor;

  @override
  Widget build(BuildContext context) {
    return Text(
      name,
      style: style.copyWith(
        color: textColor ?? Theme.of(context).textTheme.bodyLarge?.color,
        letterSpacing: 1.0,
        fontWeight: fontWeight,
        fontFamily: 'Poppins',
      ),
      textAlign: align,
      maxLines: maxLines, // Set the maxLines property
      overflow:
          TextOverflow.ellipsis, // Show ellipsis if text exceeds the max lines
    );
  }
}
