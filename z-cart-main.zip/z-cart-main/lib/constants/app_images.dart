class AppImages {
  static const String logo = "assets/images/starniklogofooter.png";
  static const String sliderImage1 =
      "https://laz-img-cdn.alicdn.com/images/ims-web/TB1LLFTsljTBKNjSZFuXXb0HFXa.jpg_1200x1200.jpg";
  static const String sliderImage2 =
      "https://laz-img-cdn.alicdn.com/images/ims-web/TB1LLFTsljTBKNjSZFuXXb0HFXa.jpg_1200x1200.jpg";
  static const String sliderImage3 =
      "https://laz-img-cdn.alicdn.com/images/ims-web/TB1LLFTsljTBKNjSZFuXXb0HFXa.jpg_1200x1200.jpg";
  static const String sliderImage4 =
      "https://laz-img-cdn.alicdn.com/images/ims-web/TB1LLFTsljTBKNjSZFuXXb0HFXa.jpg_1200x1200.jpg";

  static const String noResults = "assets/images/no_results_found.jpg";
}
