class AppStrings {
  static const String brandUrl = " ";
  static const String brandName = "Demo Cart ";
  static const String allProducts = "All Products ";
  static const String seeAll = "See All ";
  static const String noResultsFound = "No Results Found ";
  static const String myFav = "My Favorites ";
  static const String newArrivals = "New Arrivals ";
  static const String shopByCategory = "Shop by Category ";
  static const String buyAgain = "Buy Again ";
  static const String filterByCategory = "Filter by Category";
  static const String buyNow = "Buy Now";
  static const String myCart = "My Cart";
  static const String addToCart = "Add to Cart";
  static const String total = "Total";
  static const String shopByPrice = "Shop By Price";
}

class AppBuyNowString {
  static const String chooseYourModePaf = "Choose your mode of Payment";
  static const String sucessAddedCart = "Sucessfully Added in your cart";
  static const String continueShopping = "Continue Shopping";

  static const String yourOrderHasPlaced =
      "Your Order has been Sucessfully Placed";

  static const String orderPlaced = "Order Placed";
  static const String shippingAddress = "Shipping Address";
  static const String shippingtoname = "PradeeptheDeveloper";
  static const String shippingAoAddress = "3339-3201 W Walnut St";

  static const String shippingToCity = "Chicago, IL 60624, USA";
}

class AppWalkthroughString {
  static const String skip = "Skip";
  static const String next = "Next";
  static const String previous = "Previous";
  static const String getStarted = "Get Started";

  static const String page1Title = "Welcome to Z-Cart";
  static const String page1Desc =
      "Discover a world of convenient shopping at your fingertips. Browse through a wide range of products and find the best deals for your needs.";

  static const String page2Title = "Shop Anytime, Anywhere";
  static const String page2Desc =
      "With our mobile app, you can shop from the comfort of your home or on the go. Enjoy a seamless shopping experience across all your devices.";

  static const String page3Title = "Secure and Hassle-free Payments";
  static const String page3Desc =
      "Shop with confidence knowing your payments are secure. Our app offers multiple payment options, making your checkout process quick and hassle-free.";
}

class AppSettingStrings {
  static const String settings = "Settings";
  static const String darkmode = "Dark mode";
  static const String accSetting = "Account Setting";
  static const String customerService = "Customer Service";
  static const String legalAbout = "Legal & About";
  static const String switchAccount = "Switch Account";
  static const String signOut = "Sign Out";
}

class SnackBarMessages {
  static const String timeout = "Request Timed Out.";
  static const String unknownError = "Unknown Error.";
  static const String checkInternet = "Please check your internet connection.";
}

class Loader {
  static const String pleaseWait = "Please wait";
}

class AppStringsLogin {
  static const String brandName = "Zooblie Cart";
  static const String logoSloganText = "QUALITY PRODUCTS AT AFFORDABLE COST";
  static const String logIn = "LOGIN";
  static const String logInSlogan = "We are happy to see you again";
  static const String email = "Email";
  static const String password = "Password";
  static const String enterPassword = "Enter you Password";
  static const String enteremail = "Enter you Email ID";
  static const String forgetPassword = "Forget Password?";
  static const String signupSlogan = "Don't have an Account yet?";
  static const String signUp = "Signup";
  static const String signinSlogan = "Already have an Account?";
  static const String signUpSlogan = "Sign Up to get Started";
  static const String resetPassword = "Reset Password";
  static const String resetPasswordSlogan =
      "Enter your email address and we will send you the recovery link";
  static const String send = "Send";
}
