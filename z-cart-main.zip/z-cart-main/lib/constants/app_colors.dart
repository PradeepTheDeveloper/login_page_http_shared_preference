import 'package:flutter/material.dart' show Color;

class AppColors {
  static const Color appPrimaryColor = Color(0xffF9AA33);
  static const Color appSecondaryColor = Color(0xff232F34);
  static const Color appColorBlack = Color(0xff000000);
  static const Color appColorWhite = Color(0xffffffff);
  static const Color appColorRed = Color(0xffFF0000);
  static const Color orange = Color(0xffF9AA33);
  static const Color AppColorGrey = Color(0xff808080);
}
