import 'package:flutter/widgets.dart';
import 'package:sample_cart/view/order_page.dart';
import 'package:sample_cart/view/home_page.dart';
import 'package:sample_cart/view/password_rec.dart';
import 'package:sample_cart/view/sign_up.dart';

import '../view/buy_now.dart';
import '../view/login.dart';
import '../view/my_cart.dart';
import '../view/product_list.dart';
import '../view/product_description.dart';
import '../view/product_my_favorites.dart';
import '../view/walkthrough_screen.dart';

class AppRoutes {
  // static const String productList = '/productList';
  // static const String productCategoryList = '/productCategoryList';
  // static const String productDescription = '/productDescription';

  static Map<String, WidgetBuilder> get routes {
    return {
      WalkthroughScreen.routeName: (ctx) => WalkthroughScreen(),
      HomePage.routeName: (ctx) => HomePage(),
      ProductList.routeName: (ctx) => const ProductList(),
      ProductDescription.routeName: (ctx) => const ProductDescription(),
      ProductMyFavorites.routeName: (ctx) => const ProductMyFavorites(),
      MyCart.routeName: (ctx) => const MyCart(),
      OrderPage.routeName: (ctx) => OrderPage(),
      LoginPage.routeName: (ctx) => LoginPage(),
      SignUpPage.routeName: (ctx) => SignUpPage(),
      PasswordRecPage.routeName: (ctx) => PasswordRecPage(),
      BuyNowPage.routeName: (ctx) => BuyNowPage(),
    };
  }
}
