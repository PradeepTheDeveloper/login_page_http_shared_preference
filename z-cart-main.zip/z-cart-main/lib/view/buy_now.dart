import 'package:flutter/material.dart';
import 'package:sample_cart/route/route.dart';
import 'package:sample_cart/view/order_page.dart';
import '/constants/app_constants.dart';

class BuyNowPage extends StatelessWidget {
  static const routeName = '/product-buyNow';

  const BuyNowPage({super.key});
  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return Scaffold(
      appBar: AppBar(
          title: AppTextStyle(
        name: AppBuyNowString.chooseYourModePaf,
        style: textTheme.bodyMedium!,
      )),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              buildPaymentOptionCard(
                  "Credit Card / Debit Card", Icons.credit_card),
              const SizedBox(height: 16),
              buildPaymentOptionCard("GPay / Apple Pay", Icons.payment),
              const SizedBox(height: 16),
              buildPaymentOptionCard("Cash on Delivery", Icons.monetization_on),
              const SizedBox(height: 16),
              buildPaymentOptionCard("Net Banking", Icons.web),
              const SizedBox(height: 16),
              buildPaymentOptionCard("Emi", Icons.web_outlined),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildPaymentOptionCard(String title, IconData icon) {
    return GestureDetector(
      onTap: () {
        NavigationService.pushNamed(OrderPage.routeName);
      },
      child: Card(
        elevation: 2,
        shadowColor: Theme.of(currentContext).primaryColor,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(icon),
                  const SizedBox(width: 16),
                  AppTextStyle(
                    name: title,
                    style: textTheme.bodyMedium!,
                  ),
                ],
              ),
              const Icon(Icons.arrow_right_rounded),
            ],
          ),
        ),
      ),
    );
  }
}
