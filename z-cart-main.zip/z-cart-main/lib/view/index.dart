import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/view/widgets/loader.dart';
import '../constants/app_constants.dart';
import '../controller/products_controller.dart';
import '../route/route.dart';
import 'product_list.dart';
import 'widgets/image_slider.dart';
import 'widgets/product_category_slider.dart';
import 'widgets/product_price_grid.dart';
import 'widgets/product_tile_buy_again.dart';
import 'widgets/product_tile_new_arrivals.dart';

class IndexHome extends StatefulWidget {
  @override
  State<IndexHome> createState() => _IndexHomeState();
}

class _IndexHomeState extends State<IndexHome> {
  void handlePriceSelected(String categoryName) async {
    currentContext = context;
    showLoader(Loader.pleaseWait);

    await Provider.of<ProductController>(context, listen: false)
        .filterProductsByCategory('All');
    final productController =
        Provider.of<ProductController>(context, listen: false);
    await productController.fetchProducts();
    await productController.fetchCategories();
    // Close the loader dialog before navigating to the ProductList page
    //Navigator.pop(currentContext);
    // ignore: use_build_context_synchronously
    NavigationService.pop(currentContext);
    NavigationService.pushNamed(ProductList.routeName, arguments: 'All');
  }

  void handleCategorySelected(String categoryName) async {
    currentContext = context;
    showLoader(Loader.pleaseWait);

    await Provider.of<ProductController>(context, listen: false)
        .filterProductsByCategory(categoryName);
    final productController =
        Provider.of<ProductController>(context, listen: false);
    await productController.fetchProducts();
    await productController.fetchCategories();
    // Close the loader dialog before navigating to the ProductList page
    //Navigator.pop(currentContext);
    // ignore: use_build_context_synchronously
    NavigationService.pop(currentContext);
    NavigationService.pushNamed(ProductList.routeName, arguments: categoryName);
  }

  @override
  Widget build(BuildContext context) {
    final productController = Provider.of<ProductController>(context);
    final fiveProducts = productController.productsWithLimit;
    currentContext = context;
    return Scaffold(
      appBar: AppBar(
        title: AppTextStyle(
          name: AppStrings.brandName,
          style: textTheme.titleMedium!,
        ),
      ),
      body: fiveProducts.isEmpty
          ? Center(
              child: CircularProgressIndicator(
              color: AppColors.appPrimaryColor,
            ))
          : SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    ImageSlider(),
                    const SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          AppTextStyle(
                            name: AppStrings.shopByCategory,
                            style: textTheme.bodyMedium!,
                            fontWeight: FontWeight.bold,
                          ),
                          TextButton(
                            onPressed: () async {
                              showLoader(Loader.pleaseWait);

                              await Provider.of<ProductController>(context,
                                      listen: false)
                                  .filterProductsByCategory("All");

                              NavigationService.pop(currentContext);
                              NavigationService.pushNamed(
                                ProductList.routeName,
                              );
                              // Handle the "See All" action here
                              // For example, you can navigate to a new screen to show all products
                            },
                            child: AppTextStyle(
                              name: AppStrings.seeAll,
                              style: textTheme.bodyMedium!,
                              textColor: AppColors.appPrimaryColor,
                            ),
                          ),
                        ],
                      ),
                    ),

                    CategorySlider(
                      onCategorySelected: handleCategorySelected,
                    ),
                    const SizedBox(height: 10),

                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          AppTextStyle(
                            name: AppStrings.shopByPrice,
                            style: textTheme.bodyMedium!,
                            fontWeight: FontWeight.bold,
                          ),
                        ],
                      ),
                    ),
                    PriceGrid(
                      onCategorySelected: handlePriceSelected,
                    ),
                    const SizedBox(height: 10),

                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          AppTextStyle(
                            name: AppStrings.newArrivals,
                            style: textTheme.bodyMedium!,
                            fontWeight: FontWeight.bold,
                          ),
                          TextButton(
                            onPressed: () async {
                              showLoader(Loader.pleaseWait);

                              await Provider.of<ProductController>(context,
                                      listen: false)
                                  .filterProductsByCategory("All");

                              NavigationService.pop(currentContext);
                              NavigationService.pushNamed(
                                ProductList.routeName,
                              );
                              // Handle the "See All" action here
                              // For example, you can navigate to a new screen to show all products
                            },
                            child: AppTextStyle(
                              name: AppStrings.seeAll,
                              style: textTheme.bodyMedium!,
                              textColor: AppColors.appPrimaryColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Use NeverScrollableScrollPhysics for GridView.builder

                    SizedBox(
                      height:
                          650, // You can set the desired height for the GridView
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 10,
                          crossAxisSpacing: 10,
                          childAspectRatio: 1 / 1,
                        ),
                        itemCount: fiveProducts.length +
                            1, // Add +1 for the "See All" item
                        itemBuilder: (context, index) {
                          if (index == fiveProducts.length) {
                            // Render the "See All" item
                            return GestureDetector(
                              onTap: () async {
                                currentContext = context;
                                showLoader(Loader.pleaseWait);

                                await Provider.of<ProductController>(context,
                                        listen: false)
                                    .filterProductsByCategory("All");

                                NavigationService.pop(currentContext);
                                NavigationService.pushNamed(
                                  ProductList.routeName,
                                );
                                // Handle the "See All" action here
                                // For example, you can navigate to a new screen to show all products
                              },
                              child: Container(
                                color: Theme.of(context).cardColor,
                                child: Center(
                                  child: AppTextStyle(
                                    name: AppStrings.seeAll,
                                    style: textTheme.bodyMedium!,
                                    textColor: AppColors.appPrimaryColor,
                                  ),
                                ),
                              ),
                            );
                          } else {
                            final product = fiveProducts[index];
                            return ProductTileNewArrivals(product);
                          }
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          AppTextStyle(
                            name: AppStrings.buyAgain,
                            style: textTheme.bodyMedium!,
                            fontWeight: FontWeight.bold,
                          ),
                          TextButton(
                            onPressed: () async {
                              showLoader(Loader.pleaseWait);

                              await Provider.of<ProductController>(context,
                                      listen: false)
                                  .filterProductsByCategory("All");

                              NavigationService.pop(currentContext);
                              NavigationService.pushNamed(
                                ProductList.routeName,
                              );
                              // Handle the "See All" action here
                              // For example, you can navigate to a new screen to show all products
                            },
                            child: AppTextStyle(
                              name: AppStrings.seeAll,
                              style: textTheme.bodyMedium!,
                              textColor: AppColors.appPrimaryColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Use NeverScrollableScrollPhysics for GridView.builder
                    SizedBox(
                      height:
                          300, // You can set the desired height for the GridView
                      child: GridView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          mainAxisSpacing: 10,
                          crossAxisSpacing: 10,
                          childAspectRatio: 1 / 1,
                        ),
                        itemCount: fiveProducts.length +
                            1, // Add +1 for the "See All" item
                        itemBuilder: (context, index) {
                          if (index == fiveProducts.length) {
                            // Render the "See All" item
                            return GestureDetector(
                              onTap: () async {
                                currentContext = context;
                                showLoader(Loader.pleaseWait);

                                await Provider.of<ProductController>(context,
                                        listen: false)
                                    .filterProductsByCategory("All");

                                NavigationService.pop(currentContext);
                                NavigationService.pushNamed(
                                  ProductList.routeName,
                                );
                                // Handle the "See All" action here
                                // For example, you can navigate to a new screen to show all products
                              },
                              child: Container(
                                color: Theme.of(context).cardColor,
                                child: Center(
                                  child: AppTextStyle(
                                    name: AppStrings.seeAll,
                                    style: textTheme.bodyMedium!,
                                    textColor: AppColors.appPrimaryColor,
                                  ),
                                ),
                              ),
                            );
                          } else {
                            final product = fiveProducts[index];
                            return ProductTileBuyAgain(product);
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
