import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample_cart/route/route.dart';
import 'package:sample_cart/view/product_description.dart';
import '/constants/app_constants.dart';
import '../controller/products_controller.dart';
import 'widgets/empty_state.dart';

// ignore: must_be_immutable
class ProductMyFavorites extends StatelessWidget {
  const ProductMyFavorites({super.key});

  @override
  Widget build(BuildContext context) {
    final productController = Provider.of<ProductController>(context);
    final categoryProducts = productController.findByFavorites();
    return Scaffold(
      appBar: AppBar(
          title: AppTextStyle(
              name: AppStrings.myFav, style: textTheme.titleSmall!)),
      body: categoryProducts.isEmpty
          ? const EmptyState(
              text: AppStrings.noResultsFound,
              img: AppImages.noResults,
            )
          : ListView.builder(
              itemCount: categoryProducts.length,
              itemBuilder: (context, index) {
                final product = categoryProducts[index];
                return ListTile(
                  leading: Image.network(
                    product.image,
                    height: 60,
                    width: 60,
                  ),
                  title: AppTextStyle(
                    name: product.title,
                    style: textTheme.bodyMedium!,
                  ),
                  subtitle: AppTextStyle(
                    name: '\$${product.price.toStringAsFixed(2)}',
                    style: textTheme.bodyMedium!,
                  ),
                  trailing: const Icon(Icons.arrow_forward),
                  onTap: () {
                    // Handle product item tap
                    NavigationService.pushNamed(ProductDescription.routeName,
                        arguments: product.id);
                  },
                );
              },
            ),
    );
  }

  static const routeName = '/product-isFavorites';
}
