import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../constants/app_constants.dart';
import 'widgets/custom_button.dart';

class PasswordRecPage extends StatefulWidget {
  const PasswordRecPage({Key? key}) : super(key: key);


  @override
  _PasswordRecPageState createState() => _PasswordRecPageState();
  static const routeName = '/password-rec';
}

class _PasswordRecPageState extends State<PasswordRecPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  bool _isLoading = false;

  @override
  void initState() {
    _controller = AnimationController(
      duration: const Duration(milliseconds: 5000),
      vsync: this,
    )..repeat();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var deviceWidth = MediaQuery.of(context).size.width;
    var deviceHeight = MediaQuery.of(context).size.height;
    final textTheme = Theme.of(context)
        .textTheme
        .apply(displayColor: Theme.of(context).colorScheme.onSurface);
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light.copyWith(
      statusBarColor: Colors.transparent,
    ));
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                const Positioned(
                  top: -200,
                  left: -300,
                  child: Opacity(
                    opacity: 0.5,
                    child: Icon(
                      Icons.circle_outlined,
                      size: 570,
                      color: AppColors.appPrimaryColor,
                    ),
                  ),
                ),
                Opacity(
                  opacity: 0.9,
                  child: Center(
                    child: SizedBox(
                      height: deviceHeight * 0.9,
                      width: deviceWidth * 0.9,
                      child: Center(
                        child: Card(
                          elevation: 10.0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          shadowColor: AppColors.appPrimaryColor,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: AppTextStyle(
                                  name: AppStrings.brandName,
                                  style: textTheme.labelMedium!,
                                ),

                                // Image.asset(
                                //   AppImages.logo,
                                //   fit: BoxFit.cover,
                                // ),
                              ),
                              AppTextStyle(
                                name: AppStrings.brandName,
                                style: textTheme.labelMedium!,
                              ),
                              const SizedBox(height: 30.0),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 30.0, vertical: 20.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    AppTextStyle(
                                      name: AppStringsLogin.resetPassword,
                                      style: textTheme.titleMedium!.copyWith(
                                          fontWeight: FontWeight.bold,
                                          color: AppColors.orange),
                                    ),
                                    AppTextStyle(
                                      name: AppStringsLogin.resetPasswordSlogan,
                                      style: textTheme.titleSmall!,
                                    ),
                                    const SizedBox(height: 40.0),
                                    TextFormField(
                                      cursorColor: Colors.black,
                                      style: const TextStyle(
                                          color: Colors.black54),
                                      decoration: const InputDecoration(
                                        icon: Icon(Icons.email,
                                            color: AppColors.orange),
                                        hintText: "Email",
                                        border: UnderlineInputBorder(
                                          borderSide:
                                              BorderSide(color: Colors.black54),
                                        ),
                                        hintStyle:
                                            TextStyle(color: Colors.black54),
                                      ),
                                    ),
                                    const SizedBox(height: 30.0),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width,
                                      child: CustomButton(
                                        text: AppStringsLogin.send,
                                        onPressed: () {},
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
