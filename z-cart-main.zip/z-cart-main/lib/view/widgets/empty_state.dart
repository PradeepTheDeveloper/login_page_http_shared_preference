import 'package:flutter/material.dart';
import 'package:sample_cart/constants/app_constants.dart';
import 'package:sample_cart/route/route.dart';
import 'package:sample_cart/view/product_list.dart';
import 'package:sample_cart/view/widgets/custom_button.dart';

class EmptyState extends StatelessWidget {
  final String img;
  final String text;

  const EmptyState({super.key, required this.img, required this.text});

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            img,
            height: 150,
            width: 150,
            fit: BoxFit.fill,
          ),
          AppTextStyle(
            name: text,
            style: textTheme.bodyLarge!,
          ),
          CustomButton(
              text: 'Shop Now',
              onPressed: () {
                NavigationService.pushNamed(ProductList.routeName);
              })
        ],
      ),
    );
  }
}
