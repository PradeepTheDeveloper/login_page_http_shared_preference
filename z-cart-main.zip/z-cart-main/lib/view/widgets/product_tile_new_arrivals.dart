import 'package:flutter/material.dart';
import 'package:sample_cart/constants/app_constants.dart';
import 'package:sample_cart/route/route.dart';
import 'package:sample_cart/view/product_description.dart';
import '../../models/products.dart';

class ProductTileNewArrivals extends StatelessWidget {
  final Product product;

  const ProductTileNewArrivals(this.product, {super.key});

  @override
  Widget build(BuildContext context) {
    return GridTile(
      footer: GridTileBar(
        backgroundColor: AppColors.appPrimaryColor.withOpacity(0.8),
        // leading: IconButton(
        //   icon: Icon(Icons.favorite),
        //   onPressed: () {},
        // ),
        title: AppTextStyle(
          name: product.title,
          style: textTheme.bodySmall!,
          maxLines: 2,
        ),
        // trailing: IconButton(
        //   icon: Icon(Icons.shopping_cart),
        //   onPressed: () {},
        // ),
      ),
      child: GestureDetector(
        onTap: () {
          
          NavigationService.pushNamed(ProductDescription.routeName,
              arguments: product.id);
        },
        child: Image.network(
          product.image,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
