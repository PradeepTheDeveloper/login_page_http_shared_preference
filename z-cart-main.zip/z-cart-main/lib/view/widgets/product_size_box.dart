import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../constants/app_colors.dart';
import '../../constants/app_styles.dart';
import '../../controller/product_selection.dart';

class SizeBox extends StatelessWidget {
  final String size;
  final bool isSelected;

  SizeBox({required this.size, required this.isSelected, required Null Function() onTap});

  @override
  Widget build(BuildContext context) {
    final model = Provider.of<ProductSelectionModel>(context);
    return GestureDetector(
      onTap: () {
        model.updateSize(size);
      },
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          border: Border.all(
            color: isSelected
                ? AppColors.appPrimaryColor
                : Theme.of(context).canvasColor,
            width: 2.0,
          ),
        ),
        margin: EdgeInsets.all(8),
        child: Center(
          child: AppTextStyle(
            name: size,
            style: TextStyle(
              color: isSelected
                  ? AppColors.appPrimaryColor
                  : AppColors.appColorBlack,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}