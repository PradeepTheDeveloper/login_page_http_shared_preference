import 'package:flutter/material.dart';

import '../../constants/app_constants.dart';

class CustomDialog extends StatelessWidget {
  final String title;
  final String content;
  final List<Widget>? actions;

  CustomDialog({
    required this.title,
    required this.content,
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: AppTextStyle(
        name: title,
        style: textTheme.bodyMedium!,
      ),
      content: AppTextStyle(
        name: content,
        style: textTheme.bodyMedium!,
      ),
      actions: actions,
    );
  }
}
