import 'package:flutter/material.dart';
import '../../models/products.dart';
import '../../route/route.dart';
import '../product_description.dart';

class ProductTileBuyAgain extends StatelessWidget {
  final Product product;

  const ProductTileBuyAgain(this.product, {super.key});

  @override
  Widget build(BuildContext context) {
    return GridTile(
      // footer: GridTileBar(
      //   backgroundColor: AppColors.appPrimaryColor.withOpacity(0.8),
      //   leading: IconButton(
      //     icon: Icon(Icons.favorite),
      //     onPressed: () {},
      //   ),
      //   title: AppTextStyle(
      //     name: product.title,
      //     style: textTheme.bodySmall!,
      //     maxLines: 2,
      //   ),
      //   trailing: IconButton(
      //     icon: Icon(Icons.shopping_cart),
      //     onPressed: () {},
      //   ),
      // ),
      child: GestureDetector(
        onTap: () {
          NavigationService.pushNamed(ProductDescription.routeName,
              arguments: product.id);
        },
        child: Image.network(
          product.image,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
