import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

import '../../constants/app_constants.dart';

class CategorySlider extends StatelessWidget {
  final Function(String) onCategorySelected;

  CategorySlider({required this.onCategorySelected});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 100,
      child: CarouselSlider(
        options: CarouselOptions(
          height: 100.0,
          viewportFraction: 0.20,
          enlargeCenterPage: false,
          enableInfiniteScroll: true,
        ),
        items: categories.map((category) {
          return Builder(
            builder: (BuildContext context) {
              return InkWell(
                onTap: () {
                  // Pass the selected category's name to the callback function
                  onCategorySelected(category['name']);
                },
                child: Column(
                  children: [
                    CircleAvatar(
                      backgroundColor: Theme.of(context).cardColor,
                      radius: 30.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            category['icon'],
                            size: 40.0,
                            color: Theme.of(context).iconTheme.color,
                          ),
                        ],
                      ),
                    ),
                    AppTextStyle(
                      style: textTheme.labelSmall!,
                      name: category['name'],
                      maxLines: 1,
                    ),
                  ],
                ),
              );
            },
          );
        }).toList(),
      ),
    );
  }
}
