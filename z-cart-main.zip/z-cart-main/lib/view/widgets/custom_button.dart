import 'package:flutter/material.dart';
import 'package:sample_cart/constants/app_colors.dart';

import '../../constants/app_styles.dart';
import '../../constants/app_variables.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final Color color;
  final Color textColor;
  final double borderRadius;
  final EdgeInsetsGeometry padding;

  const CustomButton({
    required this.text,
    required this.onPressed,
    this.color = AppColors.appPrimaryColor,
    this.textColor = Colors.white,
    this.borderRadius = 8.0,
    this.padding = const EdgeInsets.symmetric(vertical: 0.0, horizontal: 40.0),
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        foregroundColor: textColor,
        backgroundColor: color,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(borderRadius),
        ),
      ),
      child: Padding(
        padding: padding,
        child: AppTextStyle(
          name: text,
          style: textTheme.bodyMedium!,
        ),
      ),
    );
  }
}
