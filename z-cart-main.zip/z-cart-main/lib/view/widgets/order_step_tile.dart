import 'package:flutter/material.dart';
import 'package:sample_cart/constants/app_constants.dart';

class OrderStepTile extends StatelessWidget {
  final String step;
  final bool isActive;
  final bool isLastStep;

  OrderStepTile({
    required this.step,
    required this.isActive,
    required this.isLastStep,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          crossAxisAlignment:
              CrossAxisAlignment.center, // Align items to the top
          children: [
            Container(
              width: 30,
              height: 30,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 30,
                    height: 2,
                    color: isActive
                        ? AppColors.appPrimaryColor
                        : AppColors.AppColorGrey,
                  ),
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isActive
                          ? AppColors.appPrimaryColor
                          : AppColors.AppColorGrey,
                    ),
                    child: Icon(
                      isActive ? Icons.check : Icons.circle,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 8.0),
            Expanded(
              flex: 5,
              child: AppTextStyle(name: step, style: textTheme.bodyMedium!),
            ),
          ],
        ),
        SizedBox(
          height: 10,
        )
      ],
    );
  }
}
