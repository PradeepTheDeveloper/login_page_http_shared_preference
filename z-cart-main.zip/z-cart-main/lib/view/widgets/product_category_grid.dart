import 'package:flutter/material.dart';
import 'package:sample_cart/constants/app_constants.dart';
import '../../constants/app_variables.dart';

class CategoryGrid extends StatelessWidget {
  final Function(String) onCategorySelected;

  const CategoryGrid({super.key, required this.onCategorySelected});

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: categories.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 1,
        mainAxisSpacing: 1,
        childAspectRatio: 3 / 2,
      ),
      itemBuilder: (BuildContext context, int index) {
        final category = categories[index];
        final gradientColors = cardGradients[
            index % cardGradients.length]; // Get gradient colors based on index

        return InkWell(
          onTap: () {
            // Pass the selected category's name to the callback function
            onCategorySelected(category['name']);
          },
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: LayoutBuilder(
              builder: (context, constraints) {
                return Card(
                  elevation: 5,
                  shadowColor: Theme.of(context).shadowColor,
                  color: Theme.of(context).cardColor,
                  child: Stack(
                    children: [
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: ClipRRect(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(100.0),
                            topRight: Radius.circular(100.0),
                          ),
                          child: Container(
                            height: 100, // Adjust the height as needed
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: gradientColors
                                    .map((color) => color.withOpacity(0.2))
                                    .toList(),
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                              ),
                            ), // Set the color of the bottom rectangle
                          ),
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AppTextStyle(
                            name: category['name'],
                            style: textTheme.titleMedium!,
                            maxLines: 1,
                          ),
                          Center(
                            child: Icon(
                              category['icon'],
                              size: constraints.maxHeight *
                                  0.5, // Adjust the size as needed
                              color: Theme.of(context).iconTheme.color,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
