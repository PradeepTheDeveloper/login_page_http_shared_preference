import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample_cart/constants/app_constants.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:sample_cart/route/route.dart';
import 'package:sample_cart/view/product_description.dart';
import '../../controller/favorites.dart';
import '../../models/products.dart';

class ProductTile extends StatelessWidget {
  final Product product;

  const ProductTile(this.product);

  @override
  Widget build(BuildContext context) {
    final productController =
        Provider.of<FavoritesController>(context, listen: false);
    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return InkWell(
        onTap: () {
          NavigationService.pushNamed(ProductDescription.routeName,
              arguments: product.id);
        },
        child: Card(
          elevation: 2,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    Container(
                      width: constraints.maxWidth,
                      height: constraints.maxHeight * 0.5,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Image.network(
                        product.image,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Positioned(
                      right: 0,
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: Consumer<FavoritesController>(
                            builder: (context, favorites, d) {
                          return IconButton(
                            icon: Icon(
                              product.isFavorite
                                  ? Icons.favorite
                                  : Icons.favorite_border,
                              color: AppColors.appColorRed,
                            ),
                            onPressed: () {
                              productController.toggleFavoriteStatus(product);
                              debugPrint("${product.isFavorite}");
                            },
                          );
                        }),
                      ),
                    ),
                  ],
                ),
                AppTextStyle(name: product.title, style: textTheme.bodyMedium!),
                if (product.rating['rate'] != null)
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 4, vertical: 2),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Expanded(
                            child: RatingBarIndicator(
                              rating: product.rating['rate'].toDouble(),
                              itemBuilder: (context, index) => Icon(
                                Icons.star,
                                color: AppColors.orange,
                              ),
                              itemCount: 5,
                              itemSize: 20.0,
                              direction: Axis.horizontal,
                            ),
                          ),
                          Expanded(
                            child: AppTextStyle(
                                name: '(${product.rating['count']})',
                                style: textTheme.bodyMedium!),
                          )
                        ],
                      ),
                    ),
                  ),
                AppTextStyle(
                  name: '\$${product.price.toStringAsFixed(2)}',
                  style: textTheme.bodyMedium!,
                ),
              ],
            ),
          ),
        ),
      );
    });
  }
}
