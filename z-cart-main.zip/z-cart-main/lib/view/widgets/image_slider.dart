import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

import '../../constants/app_constants.dart';

class ImageSlider extends StatefulWidget {
  ImageSlider({super.key});

  @override
  State<ImageSlider> createState() => _ImageSliderState();
}

class _ImageSliderState extends State<ImageSlider> {
  List<String> imageList = [
    AppImages.sliderImage1,
    AppImages.sliderImage2,
    AppImages.sliderImage3,
    AppImages.sliderImage4,
  ];

  @override
  Widget build(BuildContext context) {
    return Center(
      child: CarouselSlider(
        items: imageList.map((imageUrl) {
          return Image.network(
            imageUrl,
          );
        }).toList(),
        options: CarouselOptions(
          autoPlay: true,
          enlargeCenterPage: true,
          aspectRatio: 16 / 9,
          height: 150,
        ),
      ),
    );
  }
}
