import 'package:flutter/material.dart';
import 'package:sample_cart/constants/app_constants.dart';

class WalkthroughPage extends StatelessWidget {
  final String imageAsset;
  final String title;
  final String description;

  WalkthroughPage({
    required this.imageAsset,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(imageAsset),
        SizedBox(height: 30.0),
        AppTextStyle(
          name: title,
          style: textTheme.bodyLarge!,
          fontWeight: FontWeight.bold,
        ),
        SizedBox(height: 10.0),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 50.0),
          child: AppTextStyle(
            name: description,
            style: textTheme.bodyMedium!,
            maxLines: 4,
            align: TextAlign.center,
          ),
        ),
      ],
    );
  }
}
