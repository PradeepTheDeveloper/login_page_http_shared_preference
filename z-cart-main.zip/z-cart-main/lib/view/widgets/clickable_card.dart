import 'package:flutter/material.dart';
import '../../constants/app_constants.dart';

class ClickableCard extends StatelessWidget {
  final String text;
  final VoidCallback onTap;

  const ClickableCard({Key? key, required this.text, required this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: 5,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              AppTextStyle(
                style: textTheme.bodyMedium!,
                name: text,
              ),
              Icon(Icons.arrow_right_rounded),
            ],
          ),
        ),
      ),
    );
  }
}
