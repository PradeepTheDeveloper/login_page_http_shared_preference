import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../constants/app_colors.dart';
import '../../controller/product_selection.dart';

class ColorBox extends StatelessWidget {
  final Color color;
  final bool isSelected;

  const ColorBox(
      {required this.color,
      required this.isSelected,
      required Null Function() onTap});

  @override
  Widget build(BuildContext context) {
    final model = Provider.of<ProductSelectionModel>(context);
    return GestureDetector(
      onTap: () {
        model.updateColor(color);
      },
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(
            color: isSelected
                ? AppColors.appPrimaryColor
                : Theme.of(context).canvasColor,
            width: 2.0,
          ),
        ),
        margin: EdgeInsets.all(8),
      ),
    );
  }
}
