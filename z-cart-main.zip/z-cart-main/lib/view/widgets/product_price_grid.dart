import 'package:flutter/material.dart';
import 'package:sample_cart/constants/app_constants.dart';
import '../../constants/app_variables.dart';

class PriceGrid extends StatelessWidget {
  final Function(String) onCategorySelected;

  const PriceGrid({super.key, required this.onCategorySelected});

  @override
  Widget build(BuildContext context) {
    currentContext = context;
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: categories.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 1,
        mainAxisSpacing: 1,
        childAspectRatio: 3 / 2,
      ),
      itemBuilder: (BuildContext context, int index) {
        final category = PriceCategory[index];
        final gradientColors = cardGradients[
            index % cardGradients.length]; // Get gradient colors based on index

        return InkWell(
          onTap: () {
            // Pass the selected category's name to the callback function
            onCategorySelected(category['name']);
          },
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: LayoutBuilder(
              builder: (context, constraints) {
                return Card(
                  elevation: 5,
                  shadowColor: Theme.of(context).shadowColor,
                  color: Theme.of(context).cardColor,
                  child: Stack(
                    children: [
                      Container(
                        height: MediaQuery.of(context)
                            .size
                            .height, // Adjust the height as needed
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: gradientColors
                                .map((color) => color.withOpacity(0.2))
                                .toList(),
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ), // Set the color of the bottom rectangle
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  AppTextStyle(
                                    name: 'Under',
                                    style: textTheme.titleMedium!,
                                    fontWeight: FontWeight.normal,
                                    maxLines: 1,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 28.0),
                                    child: AppTextStyle(
                                      name: category['name'],
                                      style: textTheme.titleMedium!,
                                      maxLines: 1,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Center(
                              child: Icon(
                                category['icon'],
                                color: Theme.of(context).iconTheme.color,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
