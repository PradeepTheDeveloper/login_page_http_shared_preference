import 'package:flutter/material.dart';

import '../../constants/app_constants.dart';

snackBar(String text, {int duration = 2}) {
  final snackBar = SnackBar(
    // margin: EdgeInsets.only(
    //     bottom: height * 0.02, left: width * 0.05, right: width * 0.05),
    behavior: SnackBarBehavior.floating,
    content: AppTextStyle(name: text, style: textTheme.bodyMedium!),

    duration: Duration(seconds: duration),
    //backgroundColor: AppColors.white,
  );
  ScaffoldMessenger.of(currentContext).showSnackBar(snackBar);
}

removeSnackBar(context) {
  ScaffoldMessenger.of(currentContext).removeCurrentSnackBar();
}
