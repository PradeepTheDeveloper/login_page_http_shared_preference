import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';
import '../controller/products_controller.dart';
import '../route/route.dart';
import '/constants/app_constants.dart';

import 'product_list.dart';
import 'widgets/loader.dart';
import 'widgets/order_step_tile.dart';
import 'widgets/product_tile_buy_again.dart';

class OrderPage extends StatelessWidget {
  static const routeName = '/product-order';

  const OrderPage({super.key});

  @override
  Widget build(BuildContext context) {
    final productController = Provider.of<ProductController>(context);
    final categoryProducts = productController.findMycart();
    final fiveProducts = productController.productsWithLimit;
    currentContext = context;
    return Scaffold(
      appBar: AppBar(
        title: AppTextStyle(
          name: AppBuyNowString.orderPlaced,
          style: textTheme.bodyMedium!,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    Icons.check,
                    size: 50,
                    color: Colors.green,
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  Flexible(
                    child: AppTextStyle(
                      name: AppBuyNowString.yourOrderHasPlaced,
                      style: textTheme.headlineSmall!,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(top: 26),
                child: Card(
                  child: ListView.builder(
                    shrinkWrap:
                        true, // Use this to wrap the ListView inside the Column
                    itemCount: categoryProducts.length,
                    itemBuilder: (context, index) {
                      final product = categoryProducts[index];
                      return ListTile(
                        leading: Image.network(
                          product.image,
                          height: 60,
                          width: 60,
                        ),
                        title: AppTextStyle(
                          name: product.title,
                          style: textTheme.bodyMedium!,
                          maxLines: 1,
                        ),
                        subtitle: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            AppTextStyle(
                              name: '\$${product.price.toStringAsFixed(2)}',
                              style: textTheme.bodyMedium!,
                            ),
                            AppTextStyle(
                              name: "Leave us a rating",
                              style: textTheme.bodyMedium!,
                            ),
                            RatingBar.builder(
                              initialRating: 5,
                              minRating: 1,
                              direction: Axis.horizontal,
                              allowHalfRating: true,
                              itemCount: 5,
                              itemSize: 20.0,
                              itemPadding:
                                  EdgeInsets.symmetric(horizontal: 1.0),
                              itemBuilder: (context, _) => Icon(
                                Icons.star,
                                color: Colors.amber,
                              ),
                              onRatingUpdate: (rating) {
                                print(rating);
                              },
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
              Center(
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 56),
                  child: ListView.builder(
                    shrinkWrap:
                        true, // Use this to wrap the ListView inside the Column
                    itemCount: steps.length,
                    itemBuilder: (context, index) {
                      return OrderStepTile(
                        step: steps[index],
                        isActive: index == 0,
                        isLastStep: index == steps.length - 1,
                      );
                    },
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: AppTextStyle(
                    name: AppBuyNowString.shippingAddress,
                    style: textTheme.bodyLarge!),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20.0, top: 8),
                child: Column(
                  children: [
                    AppTextStyle(
                      name: AppBuyNowString.shippingtoname,
                      style: textTheme.bodyMedium!,
                      textColor: AppColors.AppColorGrey,
                    ),
                    AppTextStyle(
                      name: AppBuyNowString.shippingAoAddress,
                      style: textTheme.bodyMedium!,
                      textColor: AppColors.AppColorGrey,
                    ),
                    AppTextStyle(
                      name: AppBuyNowString.shippingToCity,
                      style: textTheme.bodyMedium!,
                      textColor: AppColors.AppColorGrey,
                    ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.only(top: 26, bottom: 8),
                child: AppTextStyle(
                  name: AppStrings.buyAgain,
                  style: textTheme.bodyMedium!,
                ),
              ),
              // Use NeverScrollableScrollPhysics for GridView.builder
              SizedBox(
                height: 300, // You can set the desired height for the GridView
                child: GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 1 / 1,
                  ),
                  itemCount:
                      fiveProducts.length + 1, // Add +1 for the "See All" item
                  itemBuilder: (context, index) {
                    if (index == fiveProducts.length) {
                      // Render the "See All" item
                      return GestureDetector(
                        onTap: () async {
                          currentContext = context;
                          showLoader(Loader.pleaseWait);

                          await Provider.of<ProductController>(context,
                                  listen: false)
                              .filterProductsByCategory("All");

                          NavigationService.pop(currentContext);
                          NavigationService.pushNamed(
                            ProductList.routeName,
                          );
                          // Handle the "See All" action here
                          // For example, you can navigate to a new screen to show all products
                        },
                        child: Container(
                          color: Theme.of(context).cardColor,
                          child: Center(
                            child: AppTextStyle(
                              name: AppStrings.seeAll,
                              style: textTheme.bodyMedium!,
                              textColor: AppColors.appPrimaryColor,
                            ),
                          ),
                        ),
                      );
                    } else {
                      final product = fiveProducts[index];
                      return ProductTileBuyAgain(product);
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
