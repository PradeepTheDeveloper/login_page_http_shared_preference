import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/view/my_cart.dart';
import '/view/product_my_favorites.dart';
import '../controller/products_controller.dart';
import 'index.dart';
import 'setting_page.dart';

class HomePage extends StatefulWidget {
  static const routeNamed = '/HomePage';
  @override
  _HomePageState createState() => _HomePageState();
  static const routeName = '/home-page';
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    final productController =
        Provider.of<ProductController>(context, listen: false);
    productController.fetchProductsLimit();
    productController.fetchProducts();
    productController.fetchCategories();
  }

  int _currentIndex = 0;

  final List<Widget> _children = [
    IndexHome(),
    MyCart(),
    ProductMyFavorites(),
    const SettingPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     
      body: Center(child: _children[_currentIndex]),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: onTabTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: 'My Cart',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favorites',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle),
            label: 'Menu',
          ),
        ],
      ),
    );
  }

  void onTabTapped(int index) {
    Future.delayed(const Duration(milliseconds: 6), () {
      setState(() {
        _currentIndex = index;
      });
    });
  }
}
