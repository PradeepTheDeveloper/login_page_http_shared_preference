import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controller/favorites.dart';
import '/constants/app_constants.dart';
import '/view/order_page.dart';
import '../controller/add_to_cart.dart';
import '../controller/product_selection.dart';
import '../controller/products_controller.dart';
import '../route/route.dart';
import 'my_cart.dart';
import 'widgets/common_dialogbox.dart';
import 'widgets/custom_button.dart';
import 'widgets/product_color_box.dart';
import 'widgets/product_size_box.dart';

// ignore: must_be_immutable
class ProductDescription extends StatelessWidget {
  const ProductDescription({super.key});

  @override
  Widget build(BuildContext context) {
    int? args = ModalRoute.of(context)!.settings.arguments as int?;
    final productController = Provider.of<ProductController>(context);
    final categoryProducts = productController.findByID(args!);
    final fiveProducts = productController.productsWithLimit;
    final productMyCartController =
        Provider.of<AddToCartController>(context, listen: false);
    final model = Provider.of<ProductSelectionModel>(context);

    final favoritesController =
        Provider.of<FavoritesController>(context, listen: false);
    return Scaffold(
      appBar: AppBar(
        title: AppTextStyle(
          name: categoryProducts[0].title,
          style: textTheme.titleSmall!,
          maxLines: 1,
        ),
        actions: [
          IconButton(
            onPressed: () {
              NavigationService.pushNamed(MyCart.routeName);
            },
            icon: const Icon(Icons.shopping_cart),
          ),
        ],
      ),
      body: categoryProducts.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.width,
                      child: Column(
                        children: [
                          Expanded(
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: categoryProducts.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Stack(
                                    children: [
                                      SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: Image.network(
                                          categoryProducts[index].image,
                                          fit: BoxFit.fitWidth,
                                        ),
                                      ),
                                      Positioned(
                                        right: 0,
                                        child: CircleAvatar(
                                          backgroundColor: Colors.white,
                                          child: Consumer<FavoritesController>(
                                              builder: (context, favorites, d) {
                                            return IconButton(
                                              icon: Icon(
                                                categoryProducts[index]
                                                        .isFavorite
                                                    ? Icons.favorite
                                                    : Icons.favorite_border,
                                                color: AppColors.appColorRed,
                                              ),
                                              onPressed: () {
                                                favoritesController
                                                    .toggleFavoriteStatus(
                                                        categoryProducts[
                                                            index]);
                                                debugPrint(
                                                    "${categoryProducts[index].isFavorite}");
                                              },
                                            );
                                          }),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                          Container(
                            alignment: Alignment.center,
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: List.generate(categoryProducts.length,
                                  (index) {
                                return Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 4.0),
                                  child: Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: index == 0
                                          ? Colors.blue
                                          : Colors.grey,
                                    ),
                                  ),
                                );
                              }),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 8),

                    // Product title
                    AppTextStyle(
                      name: categoryProducts[0].title,
                      style: textTheme.bodyLarge!,
                      fontWeight: FontWeight.bold,
                    ),

                    // Product title
                    Padding(
                      padding: const EdgeInsets.only(top: 16.0),
                      child: Row(
                        children: [
                          AppTextStyle(
                            name: 'Price:',
                            style: textTheme.bodyLarge!,
                            fontWeight: FontWeight.bold,
                          ),
                          const SizedBox(
                            width: 20,
                          ),
                          AppTextStyle(
                            name: "\$ ${categoryProducts[0].price}",
                            style: textTheme.bodyLarge!,
                          ),
                        ],
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.only(top: 15, bottom: 15),
                      child: AppTextStyle(
                        name: "Product Description",
                        style: textTheme.bodyMedium!,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    // Product description
                    AppTextStyle(
                      name: categoryProducts[0].description,
                      style: textTheme.bodyMedium!,
                      maxLines: 15,
                    ),

                    const SizedBox(height: 16),

                    // Color boxes
                    AppTextStyle(
                      name: 'Select a color:',
                      style: textTheme.bodyMedium!,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        ColorBox(
                          color: Colors.red,
                          isSelected: model.selectedColor == Colors.red,
                          onTap: () {
                            model.updateColor(Colors.red);
                          },
                        ),
                        ColorBox(
                          color: Colors.blue,
                          isSelected: model.selectedColor == Colors.blue,
                          onTap: () {
                            model.updateColor(Colors.blue);
                          },
                        ),
                        ColorBox(
                          color: Colors.green,
                          isSelected: model.selectedColor == Colors.green,
                          onTap: () {
                            model.updateColor(Colors.green);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    // Size boxes
                    AppTextStyle(
                      name: 'Select a size:',
                      style: textTheme.bodyMedium!,
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 50,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: sizes.length,
                        itemBuilder: (context, index) {
                          return SizeBox(
                            size: sizes[index],
                            isSelected: sizes[index] == model.selectedSize,
                            onTap: () {
                              model.updateSize(sizes[index]);
                            },
                          );
                        },
                      ),
                    ),

                    const SizedBox(height: 32),
                    AppTextStyle(
                      name: 'You may like:',
                      style: textTheme.bodyMedium!,
                    ),

                    const SizedBox(height: 8),
                    SizedBox(
                      height: 120,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: fiveProducts.length,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () {
                              NavigationService.pushNamed(
                                  ProductDescription.routeName,
                                  arguments: fiveProducts[index].id);
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Image.network(
                                    fiveProducts[index].image,
                                    width: 100,
                                    height: 100,
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),

                    // Bottom navigation
                  ],
                ),
              ),
            ),
      bottomNavigationBar: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          // Add to cart button

          CustomButton(
              text: AppStrings.addToCart,
              onPressed: () {
                productMyCartController
                    .toggleAddtoCartStatus(categoryProducts[0]);
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return CustomDialog(
                      title: AppBuyNowString.sucessAddedCart,
                      content: '${categoryProducts[0].title}',
                      actions: [
                        // Add buttons to the dialog
                        TextButton(
                          onPressed: () {
                            // Close the dialog when the "Close" button is pressed
                            Navigator.of(context).pop();
                          },
                          child: AppTextStyle(
                            name: AppBuyNowString.continueShopping,
                            style: textTheme.bodyMedium!,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            // Close the dialog when the "Close" button is pressed
                            NavigationService.pushReplacementNamed(
                                OrderPage.routeName);
                          },
                          child: AppTextStyle(
                            name: AppStrings.buyNow,
                            style: textTheme.bodyMedium!,
                          ),
                        ),
                      ],
                    );
                  },
                );
              }),

          // Buy button

          CustomButton(
              text: AppStrings.buyNow,
              onPressed: () {
                categoryProducts[0].addToCart
                    ? null
                    : productMyCartController
                        .toggleAddtoCartStatus(categoryProducts[0]);
                NavigationService.pushNamed(MyCart.routeName);
              }),
        ],
      ),
    );
  }

  static const routeName = '/product-description';
}
