
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../controller/products_controller.dart';
import '/config/storage_keys.dart';
import '../config/shared_pref.dart';
import '../constants/app_constants.dart';
import '../controller/dark_mode.dart';
import '../route/route.dart';
import 'product_list.dart';
import 'widgets/clickable_card.dart';
import 'widgets/loader.dart';
import 'widgets/product_category_grid.dart';

class SettingPage extends StatelessWidget {
  const SettingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    void handleCategorySelected(String categoryName) async {
      // Handle the selected category here
      currentContext = context;
      showLoader(Loader.pleaseWait);

      await Provider.of<ProductController>(context, listen: false)
          .filterProductsByCategory(categoryName);
      final productController =
          Provider.of<ProductController>(context, listen: false);
      await productController.fetchProducts();
      await productController.fetchCategories();
      // Close the loader dialog before navigating to the ProductList page
      //Navigator.pop(currentContext);
      // ignore: use_build_context_synchronously
      NavigationService.pop(currentContext);
      NavigationService.pushNamed(ProductList.routeName,
          arguments: categoryName);
    }

    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppTextStyle(
                      name: AppSettingStrings.darkmode,
                      style: textTheme.bodyMedium!,
                    ),
                    Switch(
                      value: context.watch<DarkModeProvider>().isDarkMode,
                      onChanged: (value) {
                        context.read<DarkModeProvider>().isDarkMode = value;
                        SharedPref.storeBool(StorageKeys.isDarkmode, value);
                      },
                    ),
                  ],
                ),
              ),
              CategoryGrid(
                onCategorySelected: handleCategorySelected,
              ),
              Container(
                margin: EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    ClickableCard(
                      onTap: () {},
                      text: AppSettingStrings.accSetting,
                    ),
                    ClickableCard(
                      onTap: () {},
                      text: AppSettingStrings.customerService,
                    ),
                    ClickableCard(
                      onTap: () {},
                      text: AppSettingStrings.legalAbout,
                    ),
                    ClickableCard(
                      onTap: () {},
                      text: AppSettingStrings.switchAccount,
                    ),
                    ClickableCard(
                      onTap: () {},
                      text: AppSettingStrings.signOut,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
