import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample_cart/view/buy_now.dart';
import '/constants/app_constants.dart';
import '../controller/products_controller.dart';
import '../route/route.dart';
import 'widgets/empty_state.dart';

// ignore: must_be_immutable
class MyCart extends StatelessWidget {
  const MyCart({super.key});

  @override
  Widget build(BuildContext context) {
    final productController = Provider.of<ProductController>(context);
    final categoryProducts = productController.findMycart();

    double totalPrice = 0;
    for (var product in categoryProducts) {
      totalPrice += product.price * product.quantity;
    }

    return Scaffold(
      appBar: AppBar(
          title: AppTextStyle(
              name: AppStrings.myCart, style: textTheme.titleSmall!)),
      body: categoryProducts.isEmpty
          ? const EmptyState(
              text: AppStrings.noResultsFound,
              img: AppImages.noResults,
            )
          : Consumer<ProductController>(builder: (context, productdata, index) {
              return ListView.builder(
                itemCount: categoryProducts.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      leading: Image.network(
                        categoryProducts[index].image,
                        width: 100,
                        height: 100,
                        fit: BoxFit.fitHeight,
                      ),
                      title: AppTextStyle(
                        name: categoryProducts[index].title,
                        style: textTheme.bodyMedium!,
                      ),
                      subtitle: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          IconButton(
                            icon: Icon(Icons.remove),
                            onPressed: () {
                              productController.decrementQuantity(
                                  categoryProducts[index].id);
                            },
                          ),
                          AppTextStyle(
                            name: '${categoryProducts[index].quantity}',
                            style: textTheme.bodyMedium!,
                          ),
                          IconButton(
                            icon: Icon(Icons.add),
                            onPressed: () {
                              productController.incrementQuantity(
                                  categoryProducts[index].id);
                            },
                          ),
                        ],
                      ),
                      trailing: AppTextStyle(
                        name:
                            '\$${categoryProducts[index].price * categoryProducts[index].quantity}',
                        style: textTheme.bodyMedium!,
                      ),
                    ),
                  );
                },
              );
            }),
      bottomNavigationBar: categoryProducts.isEmpty
          ? null
          : Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AppTextStyle(
                        name: AppStrings.total, style: textTheme.bodyMedium!),
                    AppTextStyle(
                      name:
                          '\$${totalPrice.toStringAsFixed(2)}', // Format price with two decimal places
                      style: textTheme.bodyLarge!, fontWeight: FontWeight.bold,
                    ),
                  ],
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                  ),
                  onPressed: () {
                    NavigationService.pushNamed(BuyNowPage.routeName);
                  },
                  child: AppTextStyle(
                    name: AppStrings.buyNow,
                    style: textTheme.bodyMedium!,
                  ),
                ),
              ],
            ),
    );
  }

  static const routeName = '/product-mycart';
}
