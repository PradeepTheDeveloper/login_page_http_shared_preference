// ignore_for_file: library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/route/route.dart';
import '/view/my_cart.dart';
import '/view/product_my_favorites.dart';
import '/view/widgets/empty_state.dart';
import '../controller/products_controller.dart';
import '../constants/app_constants.dart';
import 'widgets/product_tile.dart';

class ProductList extends StatefulWidget {
  final String? selectedCategory;

  const ProductList({Key? key, this.selectedCategory}) : super(key: key);

  @override
  _ProductListState createState() => _ProductListState();
  static const routeName = '/product-detail';
}

class _ProductListState extends State<ProductList> {
  @override
  Widget build(BuildContext context) {
    final productController = Provider.of<ProductController>(context);
    final categories = productController.categories;

    return Scaffold(
      appBar: AppBar(
        title: AppTextStyle(
          name: AppStrings.allProducts,
          style: textTheme.bodyMedium!,
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.sort),
            onPressed: () {
              _showSortOptionsDialog(productController);
            },
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: Colors.black12,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                AppTextStyle(
                  name: AppStrings.filterByCategory,
                  style: textTheme.bodyMedium!,
                ),
                DropdownButton<String>(
                  value: productController.selectedCategory,
                  items: ['All', ...categories].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: AppTextStyle(
                        name: value,
                        style: textTheme.bodyMedium!,
                      ),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      productController.filterProductsByCategory(newValue!);
                    });
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: Consumer<ProductController>(
              builder: (context, productData, child) {
                final products = productData.products;

                // Apply category filtering
                final filteredProducts =
                    productController.selectedCategory == 'All'
                        ? products
                        : productController
                            .findByCategory(productController.selectedCategory);
                if (productData.isLoading) {
                  // Show the loading indicator if data is being fetched
                  return Center(child: CircularProgressIndicator());
                } else {
                  // Show the product grid if data is available
                  return filteredProducts.isEmpty
                      ? const EmptyState(
                          img: AppImages.noResults,
                          text: AppStrings.noResultsFound)
                      : GridView.builder(
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 10,
                            crossAxisSpacing: 10,
                            childAspectRatio: 1 / 2,
                          ),
                          itemCount: filteredProducts.length,
                          itemBuilder: (context, index) {
                            final product = filteredProducts[index];
                            return ProductTile(product);
                          },
                        );
                }
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TextButton(
              onPressed: () {
                NavigationService.pushNamed(ProductMyFavorites.routeName);
              },
              child: AppTextStyle(
                  name: AppStrings.myFav, style: textTheme.bodyMedium!)),
          ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: Theme.of(context).primaryColor,
              ),
              onPressed: () {
                NavigationService.pushNamed(MyCart.routeName);
              },
              child: AppTextStyle(
                  name: AppStrings.myCart, style: textTheme.bodyMedium!)),
        ],
      ),
    );
  }

  void _showSortOptionsDialog(ProductController productController) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: AppTextStyle(
            name: "Sort Options",
            style: textTheme.bodyLarge!,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: sortOptions.map((value) {
              return RadioListTile<String>(
                title: AppTextStyle(
                  name: value,
                  style: textTheme.bodyMedium!,
                ),
                value: value,
                groupValue: selectedSortOption,
                onChanged: (String? newValue) {
                  setState(() {
                    selectedSortOption = newValue!;
                    Navigator.pop(context); // Close the dialog
                    // Sort the products based on the selected option
                    if (newValue == 'Low to High') {
                      productController.sortProductsByPrice(true);
                    } else if (newValue == 'High to Low') {
                      productController.sortProductsByPrice(false);
                    }
                  });
                },
              );
            }).toList(),
          ),
        );
      },
    );
  }
}
