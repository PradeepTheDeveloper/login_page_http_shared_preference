import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '/route/route.dart';
import '/view/home_page.dart';
import '/view/login.dart';
import '../constants/app_constants.dart';
import 'widgets/custom_button.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);
  static const routeNamed = '/Login';

  @override
  _SignUpPageState createState() => _SignUpPageState();
  static const routeName = '/sign-up';
}

class _SignUpPageState extends State<SignUpPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  bool _isLoading = false;

  @override
  void initState() {
    _controller = AnimationController(
      duration: const Duration(milliseconds: 5000),
      vsync: this,
    )..repeat();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var deviceWidth = MediaQuery.of(context).size.width;
    var deviceHeight = MediaQuery.of(context).size.height;
    final textTheme = Theme.of(context)
        .textTheme
        .apply(displayColor: Theme.of(context).colorScheme.onSurface);
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light.copyWith(
      statusBarColor: Colors.transparent,
    ));
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                const Positioned(
                  top: -200,
                  left: -300,
                  child: Opacity(
                    opacity: 0.5,
                    child: Icon(
                      Icons.circle_outlined,
                      size: 570,
                      color: AppColors.appPrimaryColor,
                    ),
                  ),
                ),
                Opacity(
                  opacity: 0.9,
                  child: Center(
                    child: SizedBox(
                      height: deviceHeight * 0.9,
                      width: deviceWidth * 0.9,
                      child: Center(
                        child: Card(
                          elevation: 10.0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          shadowColor: AppColors.appPrimaryColor,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: AppTextStyle(
                                  name: AppStrings.brandName,
                                  style: textTheme.labelMedium!,
                                ),

                                // Image.asset(
                                //   AppImages.logo,
                                //   fit: BoxFit.cover,
                                // ),
                              ),
                              AppTextStyle(
                                name: AppStrings.brandName,
                                style: textTheme.labelMedium!,
                              ),
                              const SizedBox(height: 30.0),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 30.0, vertical: 20.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    AppTextStyle(
                                      name: AppStringsLogin.signUp,
                                      style: textTheme.titleMedium!.copyWith(
                                          fontWeight: FontWeight.bold,
                                          color: AppColors.orange),
                                    ),
                                    AppTextStyle(
                                      name: AppStringsLogin.signUpSlogan,
                                      style: textTheme.titleSmall!,
                                    ),
                                    const SizedBox(height: 40.0),
                                    TextFormField(
                                      // controller: widget.emailController,
                                      cursorColor: AppColors.appPrimaryColor,
                                      style: textTheme.labelMedium!,
                                      decoration: const InputDecoration(
                                        icon: Icon(Icons.email,
                                            color: AppColors.orange),
                                        hintText: "Email",
                                        border: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: AppColors.AppColorGrey),
                                        ),
                                        hintStyle: TextStyle(
                                            color: AppColors.AppColorGrey),
                                      ),
                                    ),
                                    const SizedBox(height: 30.0),
                                    TextFormField(
                                      //controller: widget.passwordController,
                                      cursorColor: Colors.black,
                                      obscureText: true,
                                      style: textTheme.labelMedium!,
                                      decoration: const InputDecoration(
                                        icon: Icon(Icons.lock,
                                            color: AppColors.orange),
                                        hintText: "Password",
                                        border: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: AppColors.AppColorGrey),
                                        ),
                                        hintStyle: TextStyle(
                                            color: AppColors.AppColorGrey),
                                      ),
                                    ),
                                    const SizedBox(height: 30.0),
                                    TextFormField(
                                      //controller: widget.passwordController,
                                      cursorColor: Colors.black,
                                      obscureText: false,
                                      style: textTheme.labelMedium!,
                                      decoration: const InputDecoration(
                                        icon: Icon(Icons.phone,
                                            color: AppColors.orange),
                                        hintText: "Phone Number",
                                        border: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: AppColors.AppColorGrey),
                                        ),
                                        hintStyle: TextStyle(
                                            color: AppColors.AppColorGrey),
                                      ),
                                    ),
                                    const SizedBox(height: 30.0),
                                    TextFormField(
                                      //controller: widget.passwordController,
                                      cursorColor: Colors.black,
                                      obscureText: false,
                                      style: textTheme.labelMedium!,
                                      decoration: const InputDecoration(
                                        icon: Icon(Icons.home,
                                            color: AppColors.orange),
                                        hintText: "Address",
                                        border: UnderlineInputBorder(
                                          borderSide: BorderSide(
                                              color: AppColors.AppColorGrey),
                                        ),
                                        hintStyle: TextStyle(
                                            color: AppColors.AppColorGrey),
                                      ),
                                    ),
                                    const SizedBox(height: 10.0),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        TextButton(
                                          onPressed: () {
                                            NavigationService
                                                .pushReplacementNamed(
                                                    LoginPage.routeName);
                                          },
                                          child: AppTextStyle(
                                            name: AppStringsLogin.signinSlogan,
                                            style: textTheme.titleMedium!,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 30.0),
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width,
                                      child: CustomButton(
                                        text: AppStringsLogin.signUp,
                                        onPressed: () {
                                          NavigationService
                                              .pushReplacementNamed(
                                                  HomePage.routeName);
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
