import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '/route/route.dart';
import '/view/home_page.dart';
import '/view/password_rec.dart';
import '/view/sign_up.dart';
import '../constants/app_constants.dart';
import 'widgets/custom_button.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);
  static const routeNamed = '/Login';

  @override
  _LoginPageState createState() => _LoginPageState();
  static const routeName = '/login';
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  // final LoginController _loginController = LoginController();
  bool _isLoading = false;
  // final TextEditingController _emailController = TextEditingController();
  // final TextEditingController _passwordController = TextEditingController();

  @override
  void initState() {
    _controller = AnimationController(
      duration: const Duration(milliseconds: 5000),
      vsync: this,
    )..repeat();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // void _signIn() async {
  //   setState(() {
  //     _isLoading = true;
  //   });
  //   final user = LoginData(
  //       email: _emailController.text, password: _passwordController.text);
  //   final token = await _loginController.signIn(user, 'text');

  //   if (token != null) {
  //     //navigate to Page
  //     debugPrint('login Sucess $LoginData');
  //   } else {
  //     setState(() {
  //       _isLoading = false;
  //     });

  //     Get.defaultDialog(title: "Invalid email or password");
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    var deviceWidth = MediaQuery.of(context).size.width;
    var deviceHeight = MediaQuery.of(context).size.height;
    final textTheme = Theme.of(context)
        .textTheme
        .apply(displayColor: Theme.of(context).colorScheme.onSurface);
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light.copyWith(
      statusBarColor: Colors.transparent,
    ));
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                const Positioned(
                  top: -200,
                  left: -300,
                  child: Opacity(
                    opacity: 0.5,
                    child: Icon(
                      Icons.circle_outlined,
                      size: 570,
                      color: AppColors.appPrimaryColor,
                    ),
                  ),
                ),
                Opacity(
                  opacity: 0.9,
                  child: Center(
                    child: SizedBox(
                      height: deviceHeight * 0.9,
                      width: deviceWidth * 0.9,
                      child: Center(
                        child: Card(
                          elevation: 10.0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          shadowColor: AppColors.appPrimaryColor,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: AppTextStyle(
                                  name: AppStrings.brandName,
                                  style: textTheme.labelMedium!,
                                ),

                                // Image.asset(
                                //   AppImages.logo,
                                //   fit: BoxFit.cover,
                                // ),
                              ),
                              AppTextStyle(
                                name: AppStrings.brandName,
                                style: textTheme.labelMedium!,
                              ),
                              const SizedBox(height: 30.0),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 30.0, vertical: 20.0),
                                child: SingleChildScrollView(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      AppTextStyle(
                                        name: AppStringsLogin.logIn,
                                        style: textTheme.titleMedium!.copyWith(
                                            fontWeight: FontWeight.bold,
                                            color: AppColors.orange),
                                      ),
                                      AppTextStyle(
                                        name: AppStringsLogin.logInSlogan,
                                        style: textTheme.titleSmall!,
                                      ),
                                      const SizedBox(height: 40.0),
                                      TextFormField(
                                        //controller: ,
                                        cursorColor: Colors.black,
                                        style: const TextStyle(
                                            color: Colors.black54),
                                        decoration: const InputDecoration(
                                          icon: Icon(Icons.email,
                                              color: AppColors.orange),
                                          hintText: "Email",
                                          border: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black54),
                                          ),
                                          hintStyle:
                                              TextStyle(color: Colors.black54),
                                        ),
                                      ),
                                      const SizedBox(height: 30.0),
                                      TextFormField(
                                        //controller: ,
                                        cursorColor: Colors.black,
                                        obscureText: true,
                                        style: const TextStyle(
                                            color: Colors.black54),
                                        decoration: const InputDecoration(
                                          icon: Icon(Icons.lock,
                                              color: AppColors.orange),
                                          hintText: "Password",
                                          border: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black54),
                                          ),
                                          hintStyle:
                                              TextStyle(color: Colors.black54),
                                        ),
                                      ),
                                      const SizedBox(height: 10.0),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          TextButton(
                                            onPressed: () {
                                              // add code to handle forget password functionality
                                              NavigationService.pushNamed(
                                                  PasswordRecPage.routeName);
                                            },
                                            child: AppTextStyle(
                                              name: AppStringsLogin
                                                  .forgetPassword,
                                              style: textTheme.titleMedium!,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 30.0),
                                      SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        child: CustomButton(
                                          text: AppStringsLogin.logIn,
                                          onPressed: () {
                                            NavigationService
                                                .pushReplacementNamed(
                                                    HomePage.routeName);
                                          },
                                        ),
                                      ),
                                      const SizedBox(height: 30.0),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          AppTextStyle(
                                            name: AppStringsLogin.signupSlogan,
                                            style: textTheme.titleSmall!,
                                          ),
                                          TextButton(
                                            onPressed: () {
                                              // add code to handle forget password functionality
                                              NavigationService.pushNamed(
                                                  SignUpPage.routeName);
                                            },
                                            child: AppTextStyle(
                                              name: AppStringsLogin.signUp,
                                              style: textTheme.titleSmall!
                                                  .copyWith(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: AppColors.orange),
                                            ),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
