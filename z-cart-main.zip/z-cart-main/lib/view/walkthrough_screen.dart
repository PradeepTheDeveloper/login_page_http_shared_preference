import 'package:flutter/material.dart';
import '/constants/app_constants.dart';
import '/view/home_page.dart';
import '../route/route.dart';
import 'login.dart';
import 'widgets/custom_button.dart';
import 'widgets/walkthrough.dart';

class WalkthroughScreen extends StatefulWidget {
  const WalkthroughScreen({super.key});

  @override
  _WalkthroughScreenState createState() => _WalkthroughScreenState();

  static const routeName = '/walkthrough';
}

class _WalkthroughScreenState extends State<WalkthroughScreen> {
  final PageController _pageController = PageController(initialPage: 0);
  int _currentPage = 0;

  void _nextPage() {
    if (_currentPage < 2) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.ease,
      );
    }
  }

  void _previousPage() {
    if (_currentPage > 0) {
      _pageController.previousPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.ease,
      );
    }
  }

  void _onPageChanged(int page) {
    setState(() {
      _currentPage = page;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller: _pageController,
            onPageChanged: _onPageChanged,
            children: [
              WalkthroughPage(
                imageAsset: "assets/image1.png",
                title: AppWalkthroughString.page1Title,
                description: AppWalkthroughString.page1Desc,
              ),
              WalkthroughPage(
                imageAsset: "assets/image2.png",
                title: AppWalkthroughString.page2Title,
                description: AppWalkthroughString.page2Desc,
              ),
              WalkthroughPage(
                imageAsset: "assets/image3.png",
                title: AppWalkthroughString.page3Title,
                description: AppWalkthroughString.page3Desc,
              ),
            ],
          ),
          Positioned(
            bottom: 40.0,
            left: 0.0,
            right: 0.0,
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (int i = 0; i < 3; i++)
                      Container(
                        margin: const EdgeInsets.all(4.0),
                        width: 10.0,
                        height: 10.0,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _currentPage == i
                              ? AppColors.appPrimaryColor
                              : AppColors.AppColorGrey,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 20.0),
                if (_currentPage == 0)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomButton(
                        text: AppWalkthroughString.skip,
                        onPressed: () {
                          // Your button action here
                          NavigationService.pushReplacementNamed(
                              HomePage.routeName);
                        },
                      ),
                      CustomButton(
                        text: AppWalkthroughString.next,
                        onPressed: () {
                          // Your button action here
                          _nextPage();
                        },
                      ),
                    ],
                  )
                else if (_currentPage == 1)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomButton(
                        text: AppWalkthroughString.previous,
                        onPressed: () {
                          // Your button action here
                          _previousPage();
                        },
                      ),
                      CustomButton(
                        text: AppWalkthroughString.next,
                        onPressed: () {
                          // Your button action here
                          _nextPage();
                        },
                      ),
                    ],
                  )
                else
                  CustomButton(
                    text: AppWalkthroughString.getStarted,
                    onPressed: () {
                      // Your button action here
                      NavigationService.pushReplacementNamed(
                          LoginPage.routeName);
                    },
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
