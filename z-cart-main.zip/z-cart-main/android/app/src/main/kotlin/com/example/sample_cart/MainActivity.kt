package com.example.sample_cart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
